import React from "react";

export default function Todotitle() {
  return (
    <>
      <div className="todo-title-flexing">
        <div>
          <h1>TO DO</h1>
        </div>
      
      </div>
    </>
  );
}
