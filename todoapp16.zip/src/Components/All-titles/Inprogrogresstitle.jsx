import React from 'react'

export default function Inprogrogresstitle() {
  return (
    <div>
      <h1>In Progress</h1>
    </div>
  )
}
