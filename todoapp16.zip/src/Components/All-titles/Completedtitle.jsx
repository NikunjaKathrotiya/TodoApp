import React from 'react'

export default function Completedtitle() {
  return (
    <div>
      <h1>Completed</h1>
    </div>
  )
}
