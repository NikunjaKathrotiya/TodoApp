import React, { useState, useEffect } from "react";
import TodoFrom from "./TodoForm/TodoFrom";
import "../App.css";
import ToDo from "./TODO/ToDo";
import InProgress from "./InProgress/InProgress";
import Completed from "./Completed/Completed";
import { v4 as uuid } from "uuid";
import Todotitle from "./All-titles/Todotitle";
import Inprogrogresstitle from "./All-titles/Inprogrogresstitle";
import Completedtitle from "./All-titles/Completedtitle";
import DeleteModal from "../Components/model/Deletemodel";

export default function Home() {
  const [showModal, setShowModal] = useState(false);
  const [deleteItemId, setDeleteItemId] = useState(null);
  const [formData, setFormData] = useState(() => {
    const storedData = JSON.parse(localStorage.getItem("formData") );
    return storedData ? storedData : [];
  });

  const [toDo, setToDo] = useState(() =>
    formData.filter((item) => item.tasksection === "To Do")
  );
  const [progress, setProgress] = useState(() =>
    formData.filter((item) => item.tasksection === "In-Progress")
  );
  const [done, setDone] = useState(() =>
    formData.filter((item) => item.tasksection === "Completed")
  );

  const deleteHandler = (id) => {
    setDeleteItemId(id);
    setShowModal(true);
  };



  const closeModal = () => {
    setShowModal(false);
  };

  const formdataHandler = (allData) => {
    const newFormData = {
      id: uuid(),
      taskname: allData.taskname,
      assigned: allData.assigned,
      duration: allData.duration,
      taskdes: allData.taskdes,
      taskcategory: allData.taskcategory,
      starttime: allData.starttime,
      endtime: allData.endtime,
      tasksection: allData.tasksection,
    };

    localStorage.setItem("formData",JSON.stringify(formData))
    setFormData((prev) => [...prev, newFormData]);
    if (allData.tasksection === "To Do") {
      setToDo((prev) => [...prev, newFormData]);
    } else if (allData.tasksection === "In-Progress") {
      setProgress((prev) => [...prev, newFormData]);
    } else if (allData.tasksection === "Completed") {
      setDone((prev) => [...prev, newFormData]);
    }   
  };

  const handleDragStart = (id) => (event) => {
    event.dataTransfer.setData("id", id);
  };

  const handleDragOver = (event) => {
    event.preventDefault();
  };


  const handleDrop = (targetSection) => (event) => {
    const id = event.dataTransfer.getData("id");
    const draggedItem = formData.find((item) => item.id === id);
  
    if (draggedItem) {
      const currentSection = draggedItem.tasksection;
      let validNextSection = null;
      if (currentSection === "To Do" && targetSection === "In-Progress") {
        validNextSection = "In-Progress";
      } else if (currentSection === "In-Progress" && targetSection === "Completed") {
        validNextSection = "Completed";
      }

      if (validNextSection) {
        const updatedFormData = formData.map((item) =>
          item.id === id ? { ...item, tasksection: validNextSection } : item
        );
        setFormData(updatedFormData);
        setToDo(updatedFormData.filter((item) => item.tasksection === "To Do"));
        setProgress(updatedFormData.filter((item) => item.tasksection === "In-Progress"));
        setDone(updatedFormData.filter((item) => item.tasksection === "Completed"));
      }
    }
  };
  const confirmDelete = () => {
    const updatedFormData = formData.filter((item) => item.id !== deleteItemId);
    setFormData(updatedFormData);
    setShowModal(false); 
    console.log("delete_checking",updatedFormData);
  };
  return (
    <div className="max-width">
      <TodoFrom formdataHandler={formdataHandler} />
      <div className="todocard-flex">
        <div className="todo-flex"
          onDragOver={handleDragOver}
          onDrop={handleDrop("To Do")}
        >
          <Todotitle />
          {toDo.map((item) => (
            <div key={item.id} draggable onDragStart={handleDragStart(item.id)}>
              <ToDo
                id={item.id}
                taskname={item.taskname}
                taskcategory={item.taskcategory}
                taskdes={item.taskdes}
                tasksection={item.tasksection}
                starttime={item.starttime}
                endtime={item.endtime}
                duration={item.duration}
                assigned={item.assigned}
                deleteHandler={() => deleteHandler(item.id)}
              />
            </div>
          ))}
        </div>

        <div className="todo-flex"
          onDragOver={handleDragOver}
          onDrop={handleDrop("In-Progress")}
        >
          <Inprogrogresstitle />
          {progress.map((item) => (
            <div key={item.id} draggable onDragStart={handleDragStart(item.id)}>
              <InProgress
                id={item.id}
                taskname={item.taskname}
                taskcategory={item.taskcategory}
                taskdes={item.taskdes}
                tasksection={item.tasksection}
                starttime={item.starttime}
                endtime={item.endtime}
                duration={item.duration}
                assigned={item.assigned}
                deleteHandler={() => deleteHandler(item.id)}
              />
            </div>
          ))}
        </div>

        <div className="todo-flex"
          onDragOver={handleDragOver}
          onDrop={handleDrop("Completed")}
        >
          <Completedtitle />
          {done.map((item) => (
            <div key={item.id} >
              <Completed
                id={item.id}
                taskname={item.taskname}
                taskcategory={item.taskcategory}
                taskdes={item.taskdes}
                tasksection={item.tasksection}
                starttime={item.starttime}
                endtime={item.endtime}
                duration={item.duration}
                assigned={item.assigned}
                deleteHandler={() => deleteHandler(item.id)}
              />
            </div>
          ))}
        </div>
      </div>
      

      <DeleteModal
        isOpen={showModal}
        onClose={closeModal}
        onDelete={confirmDelete}
      />
    </div>
  );
}