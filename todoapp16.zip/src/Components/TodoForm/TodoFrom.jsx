import React, { useState } from "react";
import "../TodoForm/TodoForm.css";
import ToDo from "../TODO/ToDo";
import InProgress from "../InProgress/InProgress";
import { v4 as uuid } from "uuid";
export default function TodoFrom({ formdataHandler }) {
  const [allData, setAllData] = useState({
    id: uuid(),
    taskname: "",
    assigned: "",
    duration: "",
    taskdes: "",
    taskcategory: "",
    starttime: "",
    endtime: "",
    tasksection: "To Do", 
  });

  const allDatahandler = (event) => {
    const { name, value } = event.target;
    setAllData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const submitHandler = (event) => {
    event.preventDefault();
    formdataHandler(allData); 
    console.log(allData.tasksection);
  };


  return (
    <div>
      <div className="container">
        <div className="todo-section">
          <h1>TODO FORM</h1>
          <form onSubmit={submitHandler}>
            <div className="todo-form">
              <div className="form-group">
                <label htmlFor="task-name">Task Name:</label>
                <input
                  type="text"
                  id="task-name"
                  name="taskname"
                  onChange={allDatahandler}
                  value={allData.taskname}
                  placeholder="enter task..."
                />
              </div>

              <div className="form-group">
                <label htmlFor="assigned">Assigned To:</label>
                <select
                  id="assigned"
                  name="assigned"
                  onChange={allDatahandler}
                  value={allData.assigned}
                >
                  <option value="jiya tank">jiya tank</option>
                  <option value="dhaval shrma">dhaval shrma</option>
                  <option value="neha rutak">neha rutak</option>
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="duration">Duration of Completion:</label>
                <input
                  type="time"
                  id="duration"
                  name="duration"
                  onChange={allDatahandler}
                  value={allData.duration}
                />
              </div>
              <div className="form-group">
                <label htmlFor="taskdes" placeholder="enter description">
                  Task Description:
                </label>
                <input
                  type="text"
                  id="taskdes"
                  name="taskdes"
                  onChange={allDatahandler}
                  value={allData.taskdes}
                />
              </div>
            </div>

            <div className="todo-form">
              <div className="form-group">
                <label htmlFor="taskcategory">Select Task Category:</label>
                <select
                  id="taskcategory"
                  name="taskcategory"
                  onChange={allDatahandler}
                  value={allData.taskcategory}
                >
                  <option value="Designing">Designing</option>
                  <option value="Bug-fixing">Bug-fixing</option>
                  <option value="Office-work">Office-work</option>
                  <option value="QA">QA</option>
                </select>
              </div>
              <div className="form-group">
                <label htmlFor="starttime">Start Time:</label>
                <input
                  type="datetime-local"
                  id="starttime"
                  name="starttime"
                  onChange={allDatahandler}
                  value={allData.starttime}
                />
              </div>
              <div className="form-group">
                <label htmlFor="end-time">End Time:</label>
                <input
                  type="datetime-local"
                  id="end-time"
                  name="endtime"
                  onChange={allDatahandler}
                  value={allData.endtime}
                />
              </div>

              <div className="form-group">
                <label htmlFor="task-section">Task Section:</label>
                <select
                  id="task-section"
                  name="tasksection"
                  onChange={allDatahandler}
                  value={allData.tasksection}
                >
                  <option value="To Do">To Do</option>
                  <option value="In-Progress">In Progress</option>
                </select>
              </div>
            </div>
            <div className="add-btn">
              <button type="submit">Add Todo</button>
            </div>
          </form>
        </div>
  
      </div>
    </div>
  );
}